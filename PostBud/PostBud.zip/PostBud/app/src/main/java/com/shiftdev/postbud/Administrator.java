package com.shiftdev.postbud;

public class Administrator extends Account {

}
