package com.shiftdev.postbud;

public abstract class Account {

}

