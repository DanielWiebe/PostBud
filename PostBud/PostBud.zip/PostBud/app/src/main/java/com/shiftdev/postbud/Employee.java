package com.shiftdev.postbud;

public class Employee extends Account{

}
